import Link from "next/link";

type Schedule = {
  id: string;
  title: string;
  class_date: string;
  start_time: string;
  end_time: string;
  remaining: number;
};

type Props = {
  schedules: Schedule[];
};

export default function CourseScheduleList({
  schedules,
}: Props) {
  if (schedules.length === 0) {
    return (
      <div className="mt-16 rounded-3xl bg-gray-100 p-10 text-center">
        <h3 className="text-2xl font-bold">
          目前沒有可報名梯次
        </h3>

        <p className="mt-3 text-slate-500">
          敬請期待下一梯次。
        </p>
      </div>
    );
  }

  return (
    <section className="mt-20">
      <h2 className="text-3xl font-black text-slate-900">
        可報名梯次
      </h2>

      <div className="mt-8 space-y-6">
        {schedules.map((schedule) => (
          <div
            key={schedule.id}
            className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm"
          >
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <div>
                <h3 className="text-2xl font-bold">
                  {schedule.title}
                </h3>

                <p className="mt-3 text-slate-600">
                  📅 {schedule.class_date}
                </p>

                <p className="mt-1 text-slate-600">
                  🕒 {schedule.start_time.slice(0, 5)}
                  {" - "}
                  {schedule.end_time.slice(0, 5)}
                </p>

                <p className="mt-3 font-semibold text-[#8B1E2D]">
                  剩餘名額：{schedule.remaining} 位
                </p>
              </div>

              {schedule.remaining > 0 ? (
                <Link
                  href={`/signup?schedule=${schedule.id}`}
                  className="rounded-full bg-[#8B1E2D] px-8 py-4 font-semibold text-white transition hover:bg-[#731827]"
                >
                  立即報名
                </Link>
              ) : (
                <button
                  disabled
                  className="cursor-not-allowed rounded-full bg-gray-300 px-8 py-4 font-semibold text-white"
                >
                  已額滿
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}