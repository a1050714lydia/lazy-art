export default function About() {
  return (
    <section
      id="about"
      className="py-28 bg-white"
    >
      <div className="max-w-6xl mx-auto px-6">

        <div className="text-center">

          <p className="text-amber-500 font-semibold tracking-widest uppercase">
            About Lazy Art
          </p>

       <h2 className="mt-6 text-6xl font-black text-[#8B1E2D]">
  懶得畫室 <span className="text-[#8B1E2D]">Lazy Art</span>
</h2>

       <p className="mt-8 text-xl text-slate-600 leading-10 max-w-5xl mx-auto">

            懶得畫室相信，美術不是只有畫得漂亮，而是在創作中找到自信、
            享受表達、感受生活。

            <br /><br />

            我們希望每一位孩子，都能在沒有壓力的環境裡，
            自由創作、勇敢嘗試，
            找到屬於自己的創意與成就感。

          </p>

        </div>

      </div>
    </section>
  );
}